/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poop13;

/**
 *
 * @author santiagochoralopez
 */
public class POOP13 {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) {
        // TODO code application logic here
      /*  Hilo h1 = new Hilo ( "Hilo1");
        Hilo h2 = new Hilo ( "Hilo2");
         Hilo h3 = new Hilo ( "Hilo3");
    h1.start();
    h2.start();
    h3.start(); 
        
        new Hilo("Hilo4").start();
        new Hilo("Hilo5").start();*/
      new Thread(new HiloR(),"HilorR1").start();
       new Thread(new HiloR(),"HilorR2").start();
        new Thread(new HiloR(),"HilorR").start();
}
}
