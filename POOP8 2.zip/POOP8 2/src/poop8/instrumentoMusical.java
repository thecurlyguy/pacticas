/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poop8;

/**
 *
 * @author poo03alu09
 */
public interface instrumentoMusical {
    void tocar ();
    String tipodeInstrumento();
    void afinar();
    
}
