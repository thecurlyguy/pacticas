/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poop12;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 *
 * @author santiagochoralopez
 */
public class POOP12 {

    public static List<Alumno> crearListaAlumnos() {
        List<Alumno> alumnos = new ArrayList<>();
        alumnos.add(new Alumno("Juan", "Perez", "Lopez", "12345", 20));
        alumnos.add(new Alumno("Maria", "Garcia", "Hernandez", "23456", 21));
        alumnos.add(new Alumno("Luis", "Martinez", "Gomez", "34567", 22));
        alumnos.add(new Alumno("Ana", "Lopez", "Diaz", "45678", 23));
        alumnos.add(new Alumno("Carlos", "Hernandez", "Ruiz", "56789", 24));
        alumnos.add(new Alumno("Laura", "Gonzalez", "Sanchez", "67890", 20));
        alumnos.add(new Alumno("Jose", "Ramirez", "Vargas", "78901", 21));
        alumnos.add(new Alumno("Elena", "Jimenez", "Ortega", "89012", 22));
        alumnos.add(new Alumno("Fernando", "Rojas", "Mendoza", "90123", 23));
        alumnos.add(new Alumno("Sofia", "Cruz", "Morales", "01234", 24));
        return alumnos;
    }

    public static void exportarAlumnosCSV(List<Alumno> alumnos, String fileName) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            for (Alumno alumno : alumnos) {
                writer.println(alumno.toCSV());
            }
            System.out.println("Archivo CSV creado con éxito: " + fileName);
        } catch (IOException e) {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
        }
    }

    public static List<Alumno> importarAlumnosCSV(String fileName) {
        List<Alumno> alumnos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(line, ",");
                
                if (tokenizer.countTokens() != 5) {
                    System.out.println("Formato incorrecto en la línea: " + line);
                    continue;
                }
                
                try {
                    String nombre = tokenizer.nextToken();
                    String apPat = tokenizer.nextToken();
                    String apMat = tokenizer.nextToken();
                    String numCuenta = tokenizer.nextToken();
                    int edad = Integer.parseInt(tokenizer.nextToken());
                    
                    Alumno alumno = new Alumno(nombre, apPat, apMat, numCuenta, edad);
                    alumnos.add(alumno);
                } catch (NumberFormatException e) {
                    System.out.println("Error de formato en edad: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
        return alumnos;
    }

    public static void main(String[] args) {
        List<Alumno> alumnosInicial = crearListaAlumnos();
        String fileName = "alumnos.csv";
        exportarAlumnosCSV(alumnosInicial, fileName);

        List<Alumno> alumnosDesdeArchivo = importarAlumnosCSV(fileName);

        System.out.println("Alumnos leídos del archivo:");
        for (Alumno alumno : alumnosDesdeArchivo) {
            System.out.println(alumno);
        }
    }
}