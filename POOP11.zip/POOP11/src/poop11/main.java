/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poop11;

/**
 *
 * @author santiagochoralopez
 */
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class main {
    private final String nombre;
    private final String apPat;
    private final String apMat;
    private final String numCuenta;
    private final int edad;

    // Constructor
    public main(String nombre, String apPat, String apMat, String numCuenta, int edad) {
        this.nombre = nombre;
        this.apPat = apPat;
        this.apMat = apMat;
        this.numCuenta = numCuenta;
        this.edad = edad;
    }

    // Método para convertir objeto Alumno en cadena CSV
    public String toCSV() {
        return nombre + "," + apPat + "," + apMat + "," + numCuenta + "," + edad;
    }

    // Método para mostrar los datos del alumno (opcional)
    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Apellido Paterno: " + apPat + ", Apellido Materno: " + apMat +
               ", Número de Cuenta: " + numCuenta + ", Edad: " + edad;
    }

    // Método estático para crear un Alumno desde una línea CSV
    public static main fromCSV(String line) {
        StringTokenizer tokenizer = new StringTokenizer(line, ",");
        String nombre = tokenizer.nextToken();
        String apPat = tokenizer.nextToken();
        String apMat = tokenizer.nextToken();
        String numCuenta = tokenizer.nextToken();
        int edad = Integer.parseInt(tokenizer.nextToken());
        return new main(nombre, apPat, apMat, numCuenta, edad);
    }
}

public class Main {
    public static void main(String[] args) {
        // Paso 1: Crear lista de alumnos
        List<main> alumnos = new ArrayList<>();
        alumnos.add(new main("Juan", "Perez", "Lopez", "1234567890", 20));
        alumnos.add(new main("Ana", "Martinez", "Gomez", "2345678901", 21));
        alumnos.add(new main("Luis", "Garcia", "Rodriguez", "3456789012", 22));
        alumnos.add(new main("Maria", "Hernandez", "Lopez", "4567890123", 23));
        alumnos.add(new main("Carlos", "Lopez", "Ramirez", "5678901234", 24));
        alumnos.add(new main("Laura", "Sanchez", "Mendoza", "6789012345", 25));
        alumnos.add(new main("Miguel", "Gutierrez", "Flores", "7890123456", 26));
        alumnos.add(new main("Elena", "Castro", "Ruiz", "8901234567", 27));
        alumnos.add(new main("Pedro", "Dominguez", "Vargas", "9012345678", 28));
        alumnos.add(new main("Sofia", "Fernandez", "Cruz", "0123456789", 29));

        // Paso 2: Exportar la lista de alumnos a un archivo CSV
        String fileName = "alumnos.csv";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (main alumno : alumnos) {
                writer.write(alumno.toCSV());
                writer.newLine();
            }
            System.out.println("Archivo CSV creado exitosamente.");
        } catch (IOException e) {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
        }

        // Paso 3: Leer el archivo CSV y tokenizar
        List<main> alumnosDesdeArchivo = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                main alumno = main.fromCSV(line);
                alumnosDesdeArchivo.add(alumno);
            }
            System.out.println("Alumnos leídos del archivo:");
            for (main alumno : alumnosDesdeArchivo) {
                System.out.println(alumno);
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}

    
}
