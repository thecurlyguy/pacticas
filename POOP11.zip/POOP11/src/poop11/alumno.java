/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poop11;

import java.util.StringTokenizer;

/**
 *
 * @author santiagochoralopez
 */
public class alumno {
    private final String nombre;
    private final String apPat;
    private final String apMat;
    private final String numCuenta;
    private final int edad;

    // Constructor
    public alumno(String nombre, String apPat, String apMat, String numCuenta, int edad) {
        this.nombre = nombre;
        this.apPat = apPat;
        this.apMat = apMat;
        this.numCuenta = numCuenta;
        this.edad = edad;
    }

    // Método para convertir objeto Alumno en cadena CSV
    public String toCSV() {
        return nombre + "," + apPat + "," + apMat + "," + numCuenta + "," + edad;
    }

    // Método para mostrar los datos del alumno (opcional)
    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Apellido Paterno: " + apPat + ", Apellido Materno: " + apMat +
               ", Número de Cuenta: " + numCuenta + ", Edad: " + edad;
    }

    // Método estático para crear un Alumno desde una línea CSV
    public static alumno fromCSV(String line) {
        StringTokenizer tokenizer = new StringTokenizer(line, ",");
        String nombre = tokenizer.nextToken();
        String apPat = tokenizer.nextToken();
        String apMat = tokenizer.nextToken();
        String numCuenta = tokenizer.nextToken();
        int edad = Integer.parseInt(tokenizer.nextToken());
        return new alumno(nombre, apPat, apMat, numCuenta, edad);
    }
}

    
